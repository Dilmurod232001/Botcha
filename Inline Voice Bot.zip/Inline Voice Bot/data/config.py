from environs import Env

# environs kutubxonasidan foydalanish
env = Env()
env.read_env()

# .env fayl ichidan quyidagilarni o'qiymiz
BOT_TOKEN = "5889714130:AAGqg0P7jtmogBBu2H81aNrVeJ-FuHSYjNA" # Bot toekn
ADMINS = ["1849953640"]  # adminlar ro'yxati
IP = "localhost"  # Xosting ip manzili
